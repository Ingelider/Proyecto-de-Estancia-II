import tkinter as tk
from tkinter import messagebox
from cryptography.fernet import Fernet
import os

# Inicialización de clave y cifrador
if not os.path.exists("clave.key"):
    clave = Fernet.generate_key()
    with open("clave.key", "wb") as archivo_clave:
        archivo_clave.write(clave)
else:
    with open("clave.key", "rb") as archivo_clave:
        clave = archivo_clave.read()

cifrador = Fernet(clave)
archivo_cifrado = "contraseñas_encriptadas.txt"
usuario_registrado = "admin"
contraseña_registrada = "secure123"

# Función de validación
def validar_contraseña(contraseña):
    errores = []
    if len(contraseña) < 8:
        errores.append("Debe tener al menos 8 caracteres.")
    if not any(c.islower() for c in contraseña):
        errores.append("Debe contener al menos una letra minúscula.")
    if not any(c.isupper() for c in contraseña):
        errores.append("Debe contener al menos una letra mayúscula.")
    if not any(c.isdigit() for c in contraseña):
        errores.append("Debe contener al menos un número.")
    if not any(c in "!@#$%^&*()-_+=<>?/" for c in contraseña):
        errores.append("Debe contener al menos un carácter especial (!@#$%^&*()-_+=<>?/).")
    return errores

def guardar_contraseña(contraseña):
    contraseña_cifrada = cifrador.encrypt(contraseña.encode())
    with open(archivo_cifrado, "ab") as archivo:
        archivo.write(contraseña_cifrada + b'\n')

def verificar_contraseña():
    contraseña = entry_password.get()
    if contraseña == "":
        messagebox.showerror("Error", "Por favor ingrese una contraseña.")
        return
    errores = validar_contraseña(contraseña)
    if errores:
        messagebox.showerror("Errores de validación", "\n".join(errores))
    else:
        if verificar_contraseña_duplicada(contraseña):
            messagebox.showerror("Error", "Esta contraseña ya existe. Intente con otra.")
        else:
            guardar_contraseña(contraseña)
            messagebox.showinfo("Éxito", "Contraseña válida y almacenada.")
            entry_password.delete(0, tk.END)
            abrir_menu()

def verificar_contraseña_duplicada(contraseña):
    if os.path.exists(archivo_cifrado):
        with open(archivo_cifrado, "rb") as archivo:
            for linea in archivo:
                if cifrador.decrypt(linea.strip()).decode() == contraseña:
                    return True
    return False

# Ventana del menú
def abrir_menu():
    ventana.withdraw()
    menu = tk.Toplevel()
    menu.title("Menú de opciones")
    menu.geometry("300x200")
    menu.configure(bg="#aee0a6")

    tk.Label(menu, text="Seleccione una opción:", font=("Arial", 12), bg="#aee0a6").pack(pady=10)

    tk.Button(menu, text="Validar otra contraseña", bg="#00b9bd", fg="white", command=lambda: [menu.destroy(), ventana.deiconify()]).pack(pady=5)
    tk.Button(menu, text="Consultar contraseñas almacenadas", bg="#00b9bd", fg="white", command=lambda: [menu.destroy(), abrir_consulta()]).pack(pady=5)
    tk.Button(menu, text="Cerrar programa", bg="#00b9bd", fg="white", command=lambda: [menu.destroy(), ventana.quit()]).pack(pady=5)

# Ventana de consulta
def abrir_consulta():
    consulta = tk.Toplevel()
    consulta.title("Consulta de contraseñas")
    consulta.geometry("300x250")
    consulta.configure(bg="#aee0a6")

    tk.Label(consulta, text="Ingrese su usuario y contraseña:", font=("Arial", 12), bg="#aee0a6").pack(pady=10)

    tk.Label(consulta, text="Usuario:", bg="#aee0a6").pack()
    entry_usuario = tk.Entry(consulta)
    entry_usuario.pack()

    tk.Label(consulta, text="Contraseña:", bg="#aee0a6").pack()
    entry_contraseña = tk.Entry(consulta, show="")
    entry_contraseña.pack()

    tk.Button(consulta, text="Consultar", bg="#00b9bd", fg="white", command=lambda: autenticar(entry_usuario.get(), entry_contraseña.get(), consulta)).pack(pady=10)

def autenticar(usuario, contraseña, ventana_actual):
    if usuario == usuario_registrado and contraseña == contraseña_registrada:
        if os.path.exists(archivo_cifrado):
            with open(archivo_cifrado, "rb") as archivo:
                contraseñas = [cifrador.decrypt(linea.strip()).decode() for linea in archivo]
            messagebox.showinfo("Contraseñas almacenadas", "\n".join(contraseñas))
        else:
            messagebox.showinfo("Consulta", "No hay contraseñas almacenadas.")
        ventana_actual.destroy()
        abrir_menu()
    else:
        messagebox.showerror("Error", "Usuario o contraseña incorrectos. Intente nuevamente.")

# Configuración de la GUI
ventana = tk.Tk()
ventana.title("Gestor de Contraseñas")
ventana.geometry("400x300")
ventana.configure(bg="#aee0a6")

tk.Label(
    ventana,
    text="                         Evaluador de contraseñas seguras.\n"
         "Ingrese una contraseña que cumpla con los siguientes requisitos:\n"
         "1. Al menos 8 caracteres\n"
         "2. Al menos una letra minúscula\n"
         "3. Al menos una letra mayúscula\n"
         "4. Al menos un número\n"
         "5. Al menos un carácter especial",
    justify="left",
    bg="#aee0a6"
).pack(pady=10)


entry_password = tk.Entry(ventana, show="", width=30)
entry_password.pack(pady=5)

btn_validar = tk.Button(ventana, text="Validar Contraseña", bg="#00b9bd", fg="white", command=verificar_contraseña)
btn_validar.pack(pady=10)

ventana.mainloop()







