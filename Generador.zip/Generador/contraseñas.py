import tkinter as tk
from tkinter import messagebox
import secrets
import string
import os
from cryptography.fernet import Fernet

# Función para generar o cargar la clave de encriptación
def obtener_clave():
    clave_archivo = "clave_secreta.key"
    if os.path.exists(clave_archivo):
        with open(clave_archivo, "rb") as archivo:
            return archivo.read()  # Cargar la clave
    else:
        clave = Fernet.generate_key()
        with open(clave_archivo, "wb") as archivo:
            archivo.write(clave)  # Guardar la clave
        return clave

# Obtener la clave para encriptación
CLAVE_ENCRIPTACION = obtener_clave()

# Definir fernet con la clave
fernet = Fernet(CLAVE_ENCRIPTACION)

# Archivo para almacenar las contraseñas encriptadas
ARCHIVO_CONTRASEÑAS = "contraseñas_guardadas.txt"


# Archivo para almacenar las contraseñas encriptadas
ARCHIVO_CONTRASEÑAS = "contraseñas_guardadas.txt"

# Función para cargar contraseñas encriptadas desde el archivo
def cargar_contraseñas():
    contraseñas = []
    if os.path.exists(ARCHIVO_CONTRASEÑAS):
        with open(ARCHIVO_CONTRASEÑAS, "r") as archivo:
            for contraseña in archivo:
                try:
                    contraseñas.append(fernet.decrypt(contraseña.strip().encode()).decode())  # Desencriptar
                except:
                    continue  # Si hay error de desencriptación, lo ignoramos
    return contraseñas

# Función para guardar contraseñas encriptadas en el archivo
def guardar_contraseña_en_archivo(contraseña):
    with open(ARCHIVO_CONTRASEÑAS, "a") as archivo:
        archivo.write(fernet.encrypt(contraseña.encode()).decode() + "\n")  # Encriptar y guardar

# Función para eliminar la contraseña seleccionada
def eliminar_contraseña(index):
    contraseñas_generadas.pop(index)
    actualizar_archivo()

# Función para actualizar el archivo con las contraseñas actuales
def actualizar_archivo():
    with open(ARCHIVO_CONTRASEÑAS, "w") as archivo:
        for contraseña in contraseñas_generadas:
            archivo.write(fernet.encrypt(contraseña.encode()).decode() + "\n")  # Encriptar antes de guardar

# Almacenamiento de contraseñas generadas (carga las ya guardadas al iniciar)
contraseñas_generadas = cargar_contraseñas()

# Función para generar la contraseña segura basada en criterios
def generar_contraseña_segura():
    longitud = slider_longitud.get()
    caracteres = string.ascii_lowercase  # Siempre incluir minúsculas

    if var_mayusculas.get():
        caracteres += string.ascii_uppercase
    if var_numeros.get():
        caracteres += string.digits
    if var_simbolos.get():
        caracteres += string.punctuation
    if not caracteres:
        caracteres += string.ascii_lowercase  # Por defecto al menos minúsculas

    contraseña = ''.join(secrets.choice(caracteres) for _ in range(longitud))

    # Actualizar el campo de entrada con la nueva contraseña
    if entrada_contraseña.winfo_exists():
        entrada_contraseña.config(state="normal")
        entrada_contraseña.delete(0, tk.END)
        entrada_contraseña.insert(0, contraseña)
        entrada_contraseña.config(state="readonly")

    return contraseña

# Función para guardar la contraseña
def guardar_contraseña():
    if entrada_contraseña.winfo_exists():
        contraseña = entrada_contraseña.get()
        if contraseña:
            # Guardar la contraseña encriptada
            contraseñas_generadas.append(contraseña)
            guardar_contraseña_en_archivo(contraseña)
            messagebox.showinfo("Contraseña Guardada", "La contraseña ha sido guardada exitosamente.")
        else:
            messagebox.showwarning("Error", "No se ha generado ninguna contraseña.")
    else:
        messagebox.showerror("Error", "El campo de la contraseña no está disponible.")

# Función para mostrar el listado de contraseñas guardadas
def mostrar_listado_contraseñas():
    if contraseñas_generadas:
        ventana_listado = tk.Tk()
        ventana_listado.title("Listado de Contraseñas")
        ventana_listado.geometry("400x400")
        ventana_listado.config(bg="#84ecbf")

        def confirmar_eliminar(index):
            if messagebox.askyesno("Confirmar Eliminación", "¿Estás seguro de que deseas eliminar esta contraseña?"):
                eliminar_contraseña(index)
                actualizar_lista()

        lista_contraseñas = tk.Listbox(ventana_listado, font=("Arial", 12), bg="#84ecbf")
        lista_contraseñas.pack(pady=20, padx=20, fill=tk.BOTH, expand=True)

        for idx, contraseña in enumerate(contraseñas_generadas):
            lista_contraseñas.insert(tk.END, f"{idx + 1}. {contraseña}")

        btn_eliminar = tk.Button(ventana_listado, text="Eliminar Contraseña Seleccionada",
                                  command=lambda: confirmar_eliminar(lista_contraseñas.curselection()[0]),
                                  font=("Arial", 12), bg="#3ae655", fg="#000000")
        btn_eliminar.pack(pady=5)

        def actualizar_lista():
            lista_contraseñas.delete(0, tk.END)
            for idx, contraseña in enumerate(contraseñas_generadas):
                lista_contraseñas.insert(tk.END, f"{idx + 1}. {contraseña}")

        ventana_listado.mainloop()
    else:
        messagebox.showinfo("Listado vacío", "No hay contraseñas guardadas.")

# Configuración de la interfaz principal
ventana = tk.Tk()
ventana.title("Generador de Contraseñas Seguras")
ventana.geometry("400x400")
ventana.config(bg="#84ecbf")

# Entrada de la contraseña generada
entrada_contraseña = tk.Entry(ventana, font=("Arial", 14), justify="center", state="readonly", width=24)
entrada_contraseña.pack(pady=20)

# Etiqueta de longitud de la contraseña
tk.Label(ventana, text="Longitud de la contraseña:", font=("Arial", 12), bg="#84ecbf").pack(pady=5)

# Slider para la longitud de la contraseña
slider_longitud = tk.Scale(ventana, from_=8, to_=32, orient="horizontal", length=300, bg="grey")
slider_longitud.set(12)
slider_longitud.pack(pady=5)

# Opciones de criterios de generación
var_mayusculas = tk.BooleanVar()
var_numeros = tk.BooleanVar()
var_simbolos = tk.BooleanVar()

frame_criterios = tk.Frame(ventana, bg="#84ecbf")
frame_criterios.pack(pady=10)

tk.Checkbutton(frame_criterios, text="Mayúsculas", variable=var_mayusculas, font=("Arial", 10), bg="#84ecbf").pack(side="left", padx=10)
tk.Checkbutton(frame_criterios, text="Números", variable=var_numeros, font=("Arial", 10), bg="#84ecbf").pack(side="left", padx=10)
tk.Checkbutton(frame_criterios, text="Símbolos", variable=var_simbolos, font=("Arial", 10), bg="#84ecbf").pack(side="left", padx=10)

# Botón para regenerar la contraseña
btn_regenerar = tk.Button(ventana, text="Generar/Regenerar Contraseña", command=generar_contraseña_segura,
                          font=("Arial", 12), bg="#3ae655", fg="#000000")
btn_regenerar.pack(pady=10)

# Botón para usar y guardar la contraseña
btn_guardar = tk.Button(ventana, text="Usar esta contraseña", command=guardar_contraseña,
                         font=("Arial", 12), bg="#2196F3", fg="#000000")
btn_guardar.pack(pady=5)

# Botón para cerrar la aplicación
btn_cerrar = tk.Button(ventana, text="Cerrar", command=ventana.quit,
                        font=("Arial", 12), bg="#F44336", fg="#000000")
btn_cerrar.pack(pady=5)

# Credenciales para acceder al listado de contraseñas
USUARIO_CORRECTO = "admin"
CONTRASEÑA_CORRECTA = "password123"

# Función para mostrar login antes de ver listado de contraseñas
def mostrar_login():
    ventana_login = tk.Toplevel()
    ventana_login.title("Login")
    ventana_login.geometry("400x200")
    ventana_login.config(bg="#84ecbf")

    tk.Label(ventana_login, text="Usuario:", font=("Arial", 12), bg="white").pack(pady=5)
    entrada_usuario = tk.Entry(ventana_login, font=("Arial", 12))
    entrada_usuario.pack(pady=5)

    tk.Label(ventana_login, text="Contraseña:", font=("Arial", 12), bg="white").pack(pady=5)
    entrada_contraseña_login = tk.Entry(ventana_login, font=("Arial", 12), show="*")
    entrada_contraseña_login.pack(pady=5)

    def validar_login():
        usuario = entrada_usuario.get()
        contraseña = entrada_contraseña_login.get()
        if usuario == USUARIO_CORRECTO and contraseña == CONTRASEÑA_CORRECTA:
            ventana_login.destroy()
            mostrar_listado_contraseñas()
        else:
            messagebox.showerror("Error", "Usuario o contraseña incorrectos.")

    btn_login = tk.Button(ventana_login, text="Iniciar sesión", command=validar_login, font=("Arial", 12), bg="#3ae655", fg="#000000")
    btn_login.pack(pady=10)

    ventana_login.mainloop()

# Botón para ver el listado de contraseñas guardadas (requiere login)
btn_ver_listado = tk.Button(ventana, text="Ver Listado de Contraseñas", command=mostrar_login,
                            font=("Arial", 12), bg="#FF9800", fg="#000000")
btn_ver_listado.pack(pady=20)

ventana.mainloop()








